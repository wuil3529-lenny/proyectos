# 🚀 ADAPTACIÓN BACKEND AL FRONTEND - GUÍA RÁPIDA

## ¿QUÉ TIENES?

✅ Frontend profesional (React.js) **funcionando**
❌ Backend necesita **adaptar endpoints** a ese diseño

---

## 📋 LO QUE HAY QUE HACER

### PASO 1: Copiar Prompt a Claude

**Archivo**: `PROMPT_BACKEND_FRONTEND_ADAPTATION.md`

```
1. Abre en editor
2. Selecciona TODO (Ctrl+A)
3. Copia (Ctrl+C)
4. Abre Claude en VS Code
5. Pega (Ctrl+V)
6. Presiona ENTER
```

Claude va a:
- Crear endpoint `/api/dashboard/vision-general`
- Crear endpoint `/api/maquinas/estado-hoy`
- Crear endpoint `/api/usuarios/resumen-activos`
- Actualizar `/api/auth/me`
- Actualizar BD si falta algo

---

### PASO 2: Ejecutar script datos prueba

**Archivo**: `script_datos_prueba.py`

```bash
# En terminal, dentro del proyecto backend:

# 1. Activar venv
source venv/bin/activate

# 2. Ejecutar script
python script_datos_prueba.py
```

**Qué hace**:
- ✅ Crea 13 usuarios (como muestra frontend)
- ✅ Crea 13 máquinas (10 operativas, 1 mantenimiento, 2 falla)
- ✅ Crea 81 ciclos
- ✅ Crea 52 defectos
- ✅ Calcula OEE automático

---

### PASO 3: Levantar servidor

```bash
# En terminal (venv activado):

uvicorn main:app --reload

# Se abre en http://localhost:8000
# Documentación en http://localhost:8000/docs
```

---

### PASO 4: Probar en frontend

**En navegador**:
```
http://localhost:3000
(o donde esté tu frontend)

Login:
- Username: admin
- Password: admin123

Deberías ver exactamente:
- Dashboard con los 4 KPIs
- Estado de máquinas
- Lista de usuarios
```

---

## 📊 ESTRUCTURA DE DATOS QUE FRONTEND ESPERA

```json
GET /api/dashboard/vision-general

{
  "produccion_del_dia": {
    "total_kg": 3370.46,
    "total_piezas": 25907,
    "total_ciclos": 81,
    "porcentaje_defectos": 0.2,
    "oee": 99.8
  },
  "estado_maquinas": {
    "operativas": 10,
    "mantenimiento": 1,
    "detenidas": 0,
    "maquinas": [
      {
        "nombre": "Inyectora 1",
        "ciclos_hoy": 9,
        "estado": "operativa"
      },
      ...
    ]
  },
  "usuarios_sistema": {
    "total_activos": 13,
    "usuarios": [
      {
        "nombre": "Admin",
        "rol": "admin",
        "cantidad": 1
      },
      ...
    ]
  }
}
```

---

## ✅ CHECKLIST

- [ ] Copié `PROMPT_BACKEND_FRONTEND_ADAPTATION.md` a Claude
- [ ] Claude creó los nuevos endpoints
- [ ] Coloqué `script_datos_prueba.py` en carpeta backend
- [ ] Ejecuté: `python script_datos_prueba.py`
- [ ] Ejecuté: `uvicorn main:app --reload`
- [ ] Verifiqué http://localhost:8000/docs
- [ ] Frontend muestra datos correctos
- [ ] Login funciona
- [ ] Dashboard muestra KPIs
- [ ] Máquinas se actualizan
- [ ] Usuarios se listan

---

## 🆘 SI ALGO FALLA

**Error en script datos prueba**:
```
Probablemente imports incorrectos
→ Mensaje exacto a Claude
```

**Endpoint no existe en /docs**:
```
Claude no creó endpoint correctamente
→ Copiar PROMPT nuevamente
→ Ser más específico en pregunta
```

**Frontend no trae datos**:
```
CORS, JWT, o endpoint retorna mal
→ Verificar en /docs
→ Ver logs en consola backend
```

---

## 🎯 RESULTADO FINAL

Cuando funcione:
- ✅ Frontend y backend sincronizados
- ✅ Datos reales en BD
- ✅ Dashboard muestra exactamente lo de screenshot
- ✅ Login funciona
- ✅ Máquinas con estados reales
- ✅ Usuarios con roles correctos

---

**¿Listo? Comienza por PASO 1.** 🚀
