# PROMPT PARA CLAUDE - ADAPTAR BACKEND AL FRONTEND

Copia esto a Claude en VS Code:

---

```
NECESITO ADAPTAR BACKEND AL FRONTEND EXISTENTE.

ANALIZA LA ESTRUCTURA DEL FRONTEND Y CREA/ACTUALIZA LOS ENDPOINTS.

SECCIÓN 1: DASHBOARD (Visión General del Sistema)
=================================================

EL FRONTEND MUESTRA:
- PRODUCCIÓN DEL DÍA
  ├─ TOTAL PRODUCIDO: 3.370,46 kg + 25.907 piezas
  ├─ TOTAL CICLOS: 81 ciclos registrados hoy
  ├─ % DEFECTOS: 0.2% (52 piezas defectuosas)
  └─ OEE: 99.8% eficiencia general

- ESTADO DE MÁQUINAS:
  ├─ 10 Operativas (verde)
  ├─ 1 Mantenimiento (amarillo)
  ├─ 0 Detenidas (rojo)
  └─ LISTA DE MÁQUINAS:
     ├─ Inyectora 1: 9 ciclos, operativa
     ├─ Inyectora 2: 0 ciclos, falla
     ├─ Inyectora 3: 0 ciclos, mantenimiento
     ├─ Inyectora 4: 0 ciclos, operativa
     ├─ Sopladora 2: 0 ciclos, operativa
     ├─ Sopladora 4: 0 ciclos, operativa
     ├─ Sopladora 5: 1 ciclo, operativa
     └─ (más máquinas)

- USUARIOS DEL SISTEMA:
  ├─ Admin: 1
  ├─ Inspector Producción: 2
  ├─ Vendedor: 1
  ├─ Técnico: 2
  ├─ Jefe Producción: 1
  ├─ Operario Logística: 1
  ├─ Inspector Calidad: 1
  ├─ Jefe Ventas: 1
  ├─ Jefe Técnico: 1
  ├─ Molinero: 1
  ├─ Jefe Calidad: 1
  └─ Jefe Logística: 1

ENDPOINT NECESARIO:
POST /api/dashboard/vision-general
Retorna (JSON):
{
  "fecha": "2026-04-16",
  "produccion_del_dia": {
    "total_kg": 3370.46,
    "total_piezas": 25907,
    "total_ciclos": 81,
    "porcentaje_defectos": 0.2,
    "cantidad_defectos": 52,
    "oee": 99.8
  },
  "estado_maquinas": {
    "operativas": 10,
    "mantenimiento": 1,
    "detenidas": 0,
    "maquinas": [
      {
        "id": 1,
        "nombre": "Inyectora 1",
        "ciclos_hoy": 9,
        "estado": "operativa"
      },
      // ... más máquinas
    ]
  },
  "usuarios_sistema": {
    "total_activos": 13,
    "por_rol": {
      "admin": 1,
      "inspector_produccion": 2,
      "vendedor": 1,
      "tecnico": 2,
      "jefe_produccion": 1,
      // ... más roles
    },
    "lista_usuarios": [
      {
        "id": 1,
        "nombre": "Admin",
        "rol": "admin",
        "cantidad": 1
      },
      // ... más usuarios
    ]
  }
}

SECCIÓN 2: NAVEGACIÓN LATERAL
=============================

MENÚ MOSTRADO:
- Dashboard (actual)
- Máquinas
- Ciclos
- Alertas
- Reportes
- Usuarios

TODOS LOS ENDPOINTS YA EXISTEN, SOLO VERIFICAR:
✅ GET /api/maquinas (listar máquinas con estado)
✅ GET /api/ciclos (listar ciclos)
✅ GET /api/alertas (listar alertas)
✅ GET /api/reportes (listar reportes)
✅ GET /api/usuarios (listar usuarios)

SECCIÓN 3: INFORMACIÓN DEL USUARIO
===================================

MUESTRA:
- Avatar: "A" (primera letra nombre)
- Nombre: "Administrador"
- Rol: "admin"

ENDPOINT:
GET /api/auth/me
Retorna:
{
  "id": 1,
  "nombre": "Administrador",
  "rol": "admin",
  "avatar": "A"
}

SECCIÓN 4: DATOS DE MÁQUINAS
=============================

ESTRUCTURA MOSTRADA:
- Inyectora 1: 9 ciclos, operativa (verde)
- Inyectora 2: 0 ciclos, falla (rojo)
- Inyectora 3: 0 ciclos, mantenimiento (amarillo)
- Inyectora 4: 0 ciclos, operativa (verde)
- Sopladora 2-5: (misma estructura)

ENDPOINT NECESARIO:
GET /api/maquinas/estado-hoy
Retorna:
{
  "maquinas": [
    {
      "id": 1,
      "nombre": "Inyectora 1",
      "tipo": "Inyectora",
      "ciclos_hoy": 9,
      "estado": "operativa",
      "color": "green"
    },
    {
      "id": 2,
      "nombre": "Inyectora 2",
      "tipo": "Inyectora",
      "ciclos_hoy": 0,
      "estado": "falla",
      "color": "red"
    },
    // ... más máquinas
  ]
}

SECCIÓN 5: DATOS DE USUARIOS
=============================

ESTRUCTURA:
- Admin: cantidad 1
- Inspector Produccion: cantidad 2
- Vendedor: cantidad 1
- (lista completa de 13 usuarios activos)

ENDPOINT NECESARIO:
GET /api/usuarios/resumen-activos
Retorna:
{
  "total_activos": 13,
  "usuarios": [
    {
      "nombre": "Admin",
      "rol": "admin",
      "cantidad": 1
    },
    {
      "nombre": "Inspector Produccion",
      "rol": "inspector_produccion",
      "cantidad": 2
    },
    // ... más roles
  ]
}

SECCIÓN 6: VALIDACIONES IMPORTANTES
====================================

1. ESTADO MÁQUINAS (Solo 4 valores):
   - "operativa" (verde)
   - "falla" (rojo)
   - "mantenimiento" (amarillo)
   - "en_espera" (gris, no mostrado en screenshot)

2. COLORES POR ESTADO:
   - operativa = #00C853 (verde)
   - falla = #D32F2F (rojo)
   - mantenimiento = #F57C00 (naranja)
   - en_espera = #9E9E9E (gris)

3. ROLES DE USUARIO (Lista actual):
   - admin
   - inspector_produccion
   - inspector_calidad
   - jefe_produccion
   - jefe_calidad
   - jefe_tecnico
   - tecnico
   - jefe_ventas
   - vendedor
   - jefe_logistica
   - operario_logistica
   - molinero

TAREA COMPLETA:
===============

1. Crear/actualizar TODOS los endpoints arriba
2. Crear datos de prueba que coincidan con screenshot
3. Crear script para popular BD con 13 usuarios
4. Crear script para agregar máquinas reales
5. Generar ciclos y defectos para hoy
6. Verificar cálculos (total kg, piezas, OEE, %)
7. Documentación de endpoints en /docs

ARCHIVOS A ACTUALIZAR/CREAR:
- backend_fastapi_main.py (agregar endpoints)
- models_base_datos.py (verificar modelos)
- schemas_pydantic.py (agregar schemas nuevos)
- script_datos_prueba.py (CREAR - popular BD)

¿PUEDES HACERLO?
```

---

Copia y pega esto en Claude en VS Code. 🚀
