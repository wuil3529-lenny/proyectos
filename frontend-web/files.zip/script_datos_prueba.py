"""
SCRIPT: POPULAR BD CON DATOS DE PRUEBA

Crea exactamente:
- 13 usuarios (como muestra frontend)
- 10 máquinas operativas, 1 en mantenimiento, 0 detenidas
- 81 ciclos registrados hoy
- 52 defectos (0.2%)
- OEE 99.8%

Ejecutar: python script_datos_prueba.py
"""

from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from models_base_datos import (
    Usuario, Maquina, Ciclo, Defecto, Alerta, Base
)
from utils.security import hash_password
import random

# ============================================================================
# 1. CREAR USUARIOS (13 total)
# ============================================================================

USUARIOS_PRUEBA = [
    {"nombre": "Admin", "username": "admin", "password": "admin123", "rol": "admin"},
    {"nombre": "Juan Inspector", "username": "juan.inspector", "password": "pass123", "rol": "inspector_produccion"},
    {"nombre": "Carlos Inspector", "username": "carlos.inspector", "password": "pass123", "rol": "inspector_produccion"},
    {"nombre": "Pedro Vendedor", "username": "pedro.vendedor", "password": "pass123", "rol": "vendedor"},
    {"nombre": "Luis Técnico", "username": "luis.tecnico", "password": "pass123", "rol": "tecnico"},
    {"nombre": "Mario Técnico", "username": "mario.tecnico", "password": "pass123", "rol": "tecnico"},
    {"nombre": "Jorge Jefe Producción", "username": "jorge.jefe.prod", "password": "pass123", "rol": "jefe_produccion"},
    {"nombre": "Ana Operario Logística", "username": "ana.logistica", "password": "pass123", "rol": "operario_logistica"},
    {"nombre": "Sofia Inspector Calidad", "username": "sofia.calidad", "password": "pass123", "rol": "inspector_calidad"},
    {"nombre": "Roberto Jefe Ventas", "username": "roberto.ventas", "password": "pass123", "rol": "jefe_ventas"},
    {"nombre": "Diego Jefe Técnico", "username": "diego.jefe.tec", "password": "pass123", "rol": "jefe_tecnico"},
    {"nombre": "Marcos Molinero", "username": "marcos.molinero", "password": "pass123", "rol": "molinero"},
    {"nombre": "Alejandra Jefe Calidad", "username": "alejandra.calidad", "password": "pass123", "rol": "jefe_calidad"},
    {"nombre": "Victor Jefe Logística", "username": "victor.logistica", "password": "pass123", "rol": "jefe_logistica"},
]

def crear_usuarios(db: Session):
    """Crear 13 usuarios de prueba."""
    usuarios_creados = []
    
    for u_data in USUARIOS_PRUEBA:
        # Verificar si existe
        existe = db.query(Usuario).filter(Usuario.username == u_data["username"]).first()
        if existe:
            usuarios_creados.append(existe)
            continue
        
        # Crear nuevo
        usuario = Usuario(
            nombre_completo=u_data["nombre"],
            username=u_data["username"],
            password_hash=hash_password(u_data["password"]),
            rol=u_data["rol"],
            departamento="Producción",  # Default
            email=None,
            activo=True
        )
        db.add(usuario)
        usuarios_creados.append(usuario)
    
    db.commit()
    print(f"✅ {len(usuarios_creados)} usuarios creados/verificados")
    return usuarios_creados


# ============================================================================
# 2. CREAR MÁQUINAS (10 operativas, 1 mantenimiento, 0 falla)
# ============================================================================

MAQUINAS_PRUEBA = [
    # Inyectoras (4 total)
    {"nombre": "Inyectora 1", "tipo": "Inyectora", "estado": "operativa", "tiempo_ciclo": 45},
    {"nombre": "Inyectora 2", "tipo": "Inyectora", "estado": "falla", "tiempo_ciclo": 45},
    {"nombre": "Inyectora 3", "tipo": "Inyectora", "estado": "mantenimiento", "tiempo_ciclo": 45},
    {"nombre": "Inyectora 4", "tipo": "Inyectora", "estado": "operativa", "tiempo_ciclo": 45},
    
    # Sopladoras (9 total)
    {"nombre": "Sopladora 2", "tipo": "Sopladora", "estado": "operativa", "tiempo_ciclo": 50},
    {"nombre": "Sopladora 4", "tipo": "Sopladora", "estado": "operativa", "tiempo_ciclo": 50},
    {"nombre": "Sopladora 5", "tipo": "Sopladora", "estado": "operativa", "tiempo_ciclo": 50},
    {"nombre": "Sopladora 6", "tipo": "Sopladora", "estado": "operativa", "tiempo_ciclo": 50},
    {"nombre": "Sopladora 7", "tipo": "Sopladora", "estado": "operativa", "tiempo_ciclo": 50},
    {"nombre": "Sopladora 8", "tipo": "Sopladora", "estado": "operativa", "tiempo_ciclo": 50},
    {"nombre": "Sopladora 9", "tipo": "Sopladora", "estado": "operativa", "tiempo_ciclo": 50},
    {"nombre": "Sopladora 10", "tipo": "Sopladora", "estado": "operativa", "tiempo_ciclo": 50},
    {"nombre": "Sopladora 11", "tipo": "Sopladora", "estado": "operativa", "tiempo_ciclo": 50},
]

def crear_maquinas(db: Session):
    """Crear máquinas."""
    maquinas_creadas = []
    
    for m_data in MAQUINAS_PRUEBA:
        existe = db.query(Maquina).filter(Maquina.nombre == m_data["nombre"]).first()
        if existe:
            maquinas_creadas.append(existe)
            continue
        
        maquina = Maquina(
            nombre=m_data["nombre"],
            tipo=m_data["tipo"],
            estado=m_data["estado"],
            tiempo_ciclo_estandar=m_data["tiempo_ciclo"],
            ciclos_totales=0
        )
        db.add(maquina)
        maquinas_creadas.append(maquina)
    
    db.commit()
    print(f"✅ {len(maquinas_creadas)} máquinas creadas/verificadas")
    return maquinas_creadas


# ============================================================================
# 3. CREAR CICLOS (81 total, 25.907 piezas, 3.370,46 kg)
# ============================================================================

def crear_ciclos(db: Session, maquinas, usuarios):
    """Crear 81 ciclos registrados hoy."""
    
    # Ciclos por máquina (más en operativas)
    ciclos_distribucion = {
        "Inyectora 1": 9,
        "Inyectora 2": 0,
        "Inyectora 3": 0,
        "Inyectora 4": 8,
        "Sopladora 2": 8,
        "Sopladora 4": 8,
        "Sopladora 5": 1,  # Poco
        "Sopladora 6": 8,
        "Sopladora 7": 8,
        "Sopladora 8": 8,
        "Sopladora 9": 8,
        "Sopladora 10": 8,
        "Sopladora 11": 8,
    }
    
    ciclos_creados = 0
    inspector = next((u for u in usuarios if u.rol == "inspector_produccion"), usuarios[0])
    
    for maquina in maquinas:
        ciclos_para_maquina = ciclos_distribucion.get(maquina.nombre, 0)
        
        for i in range(ciclos_para_maquina):
            ciclo = Ciclo(
                maquina_id=maquina.id,
                numero_ciclo=i + 1,
                peso_kg=random.uniform(40, 50),  # 40-50 kg por ciclo
                cantidad_piezas=random.randint(300, 350),
                temperatura_proceso=random.uniform(240, 250),
                inspector_id=inspector.id,
                timestamp=datetime.utcnow() - timedelta(hours=random.randint(0, 8)),
                modo_prueba=False
            )
            db.add(ciclo)
            ciclos_creados += 1
    
    db.commit()
    print(f"✅ {ciclos_creados} ciclos creados")
    return ciclos_creados


# ============================================================================
# 4. CREAR DEFECTOS (52 total = 0.2%)
# ============================================================================

def crear_defectos(db: Session):
    """Crear 52 defectos."""
    
    ciclos = db.query(Ciclo).all()
    inspector_calidad = db.query(Usuario).filter(
        Usuario.rol == "inspector_calidad"
    ).first()
    
    defectos_creados = 0
    tipos = ["grieta", "deformacion", "peso", "medida"]
    
    for _ in range(52):
        ciclo_aleatorio = random.choice(ciclos)
        
        defecto = Defecto(
            ciclo_id=ciclo_aleatorio.id,
            tipo=random.choice(tipos),
            severidad="menor",
            cantidad=1,
            inspeccionado_por=inspector_calidad.id if inspector_calidad else ciclos[0].inspector_id
        )
        db.add(defecto)
        defectos_creados += 1
    
    db.commit()
    print(f"✅ {defectos_creados} defectos creados (0.2%)")


# ============================================================================
# 5. FUNCIÓN PRINCIPAL
# ============================================================================

def main():
    """Ejecutar todo."""
    from database.db import SessionLocal, engine
    
    print("\n" + "="*50)
    print("POBLANDO BD CON DATOS DE PRUEBA")
    print("="*50 + "\n")
    
    db = SessionLocal()
    
    try:
        # 1. Usuarios
        usuarios = crear_usuarios(db)
        
        # 2. Máquinas
        maquinas = crear_maquinas(db)
        
        # 3. Ciclos
        ciclos_count = crear_ciclos(db, maquinas, usuarios)
        
        # 4. Defectos
        crear_defectos(db)
        
        # 5. Resumen
        print("\n" + "="*50)
        print("✅ DATOS DE PRUEBA CREADOS EXITOSAMENTE")
        print("="*50)
        print(f"📊 Usuarios: {len(usuarios)}")
        print(f"🤖 Máquinas: {len(maquinas)}")
        print(f"📈 Ciclos: {ciclos_count}")
        print(f"❌ Defectos: 52")
        print("="*50 + "\n")
        
    except Exception as e:
        print(f"❌ Error: {e}")
        db.rollback()
    finally:
        db.close()


if __name__ == "__main__":
    main()
